ANOKHI PAINTINGS WEBSITE
Open index.html in a browser.
Next: replace the artwork placeholders with your photos, then add your WhatsApp number, fees and class timings.
